﻿namespace User_Management.Services
{
    public class Class1
    {

    }
}
