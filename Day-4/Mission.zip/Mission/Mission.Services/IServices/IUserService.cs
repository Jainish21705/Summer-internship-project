﻿using Mission.Entities.Entities;
using Mission.Entities.Models;

namespace Mission.Services.IServices
{
    public interface IUserService
    {
        public ResponseResult GetAllUsers();
    }
}
